package ass3;

import assg3.BufferedWriter;
import assg3.ChromeDriver;
import assg3.File;
import assg3.FileWriter;
import assg3.IOException;
import assg3.List;
import assg3.WebDriver;
import assg3.WebElement;

public class SeleniumAssignmentA4 {
	 public static void main(String[] args) throws InterruptedException, IOException {

         System.setProperty("webdriver.chrome.driver","C:\\Users\\AMIMOHAM\\Downloads\\chromedriver.exe" );

         WebDriver driver = new ChromeDriver();
         driver.get("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm?cat=G");

         driver.manage().window().maximize();
         driver.manage().deleteAllCookies();

         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

         //Get Row Count

         List<WebElement> stockName = driver.findElements(By.xpath(("//*[@id=\"topgainer-Table\"]/tbody/tr/td[1]")));

         System.out.println("=====Stockname=====");
         System.out.println(stockName.size());
         for(int i=0 ; i<stockName.size();i++) {
             System.out.println(stockName.get(i).getText());
         }

         List<WebElement> stockOpenPrice = driver.findElements(By.xpath(("//*[@id=\"topgainer-Table\"]/tbody/tr/td[2]")));

         System.out.println(stockOpenPrice.size());
         System.out.println("=====stockOpenPrice=====");
         for(int i=0 ; i<stockOpenPrice.size();i++) {
             System.out.println(stockOpenPrice.get(i).getText());
         }

         List<WebElement> stockHighPrice = driver.findElements(By.xpath(("//*[@id=\"topgainer-Table\"]/tbody/tr/td[3]")));

         System.out.println(stockHighPrice.size());
         System.out.println("=====stockHighPrice=====");
         for(int i=0 ; i<stockHighPrice.size();i++) {
             System.out.println(stockHighPrice.get(i).getText());
         }

         List<WebElement> stockLowPrice = driver.findElements(By.xpath(("//*[@id=\"topgainer-Table\"]/tbody/tr/td[4]")));

         System.out.println(stockLowPrice.size());
         System.out.println("=====stockLowPrice=====");
         for(int i=0 ; i<stockLowPrice.size();i++) {
             System.out.println(stockLowPrice.get(i).getText());
         }

         List<WebElement> date = driver.findElements(By.xpath(("//*[@id=\"topgainer-Table\"]/tbody/tr/td[10]/a")));

         System.out.println(date.size());
         System.out.println("=====date=====");
         for(int i=0 ; i<date.size();i++) {
             System.out.println(date.get(i).getText());
         }

         Thread.sleep(3000);

             File file = new File("./result/stockData.csv");
             FileWriter fw = new FileWriter(file);
             BufferedWriter bw = new BufferedWriter(fw);

             bw.write("stockName,OpenPrice,HighPrice,LowPrice,date");
             bw.newLine();
             for(int i=0;i<stockName.size();i++)
             {
                 bw.write(stockName.get(i).getText()+","+stockOpenPrice.get(i).getText().replaceAll(",", "")+","+stockHighPrice.get(i).getText().replaceAll(",", "")+","+stockLowPrice.get(i).getText().replaceAll(",", "")+","+date.get(i).getText().replaceAll(",", ""));
                 bw.newLine();
             }
             bw.close();
             fw.close();      
//         
//         int rowCount = driver.findElements(By.tagName("tr")).size();
//         
//         //Get Column Count
//         int colCount = driver.findElements(By.xpath("//thead//tr//th")).size();
//         
//         System.out.println("Row count :" + rowCount);
//         System.out.println("Col count :" + colCount);
//         
//         //Print table Data
//         for(WebElement tdata:driver.findElements(By.tagName("tr"))){
//             System.out.println(tdata.getText());
//             
//         }
     }
}

